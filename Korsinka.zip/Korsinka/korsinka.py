import json

import pygame
from random import randint
from pygame import mixer

with open("Korsinka//best.json", "r", encoding="utf-8") as file:
    stats = json.load(file)

pygame.init()
mixer.init()
speed = 4


win_width = 700
win_height = 500
wait = 0
window = pygame.display.set_mode((win_width, win_height))
game = True
start = 1
clock = pygame.time.Clock()
FPS = 60 

class GameSprite(pygame.sprite.Sprite):
    def __init__(self, img, x, y, w, h, speed):
        super().__init__()
        
        self.image = pygame.transform.scale(
            pygame.image.load(img),
            (w, h)
)
        
        self.speed = speed
        
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def draw(self):
        window.blit(self.image, (self.rect.x, self.rect.y))

    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))  

class Player(GameSprite):
    def __init__(self, img, x=0, y=0, width=10, height=10, speed=5):
        super().__init__(img, x, y, width, height,speed)

    def fall_down(self):
        self.rect.y += speed   

music_playing = False

def musik1():
    global music_playing
    if not music_playing:
        mixer.music.load("Korsinka//startmusik.mp3")
        mixer.music.play(-1)
        mixer.music.set_volume(0.5)
        music_playing = True

def musik2():
    global music_playing
    if not music_playing:
        mixer.music.load("Korsinka//3456.mp3")
        mixer.music.play(-1)
        mixer.music.set_volume(0.5)
        music_playing = True

def musik3():
    global music_playing
    if not music_playing:
        mixer.music.load("Korsinka//failmusik.mp3")
        mixer.music.play(-1)
        mixer.music.set_volume(0.5)    
        music_playing = True    

bg_sprite2 = pygame.transform.scale(pygame.image.load("Korsinka//fon.jpg"), (win_width, win_height))
korsinka = Player("Korsinka//korsinka.png", 300, 400, 150, 70)


apples = []
lives = 3
aple = 5
BLACK = (0,0,0)
RED = (255, 0, 0)
WHITE = (255,255,255)
GREEN = (0, 255, 0)
score = 0
musik = 1

def korsinka_game():

    global game, music_playing, start, musik, wait, lives, speed, score, apples, apple
    
    if start == 1:  
        window.fill(BLACK)
        if musik == 1:
            musik1()

        apples = []
        f = pygame.font.Font("Korsinka//Shrift2.otf" , 60)
        score_text1 = f.render("Apple fall" , 1, GREEN, None)
        window.blit(score_text1, (200, 20))

        f = pygame.font.Font("Korsinka//a_lcdnova3dplobl.ttf" , 35)
        score_text2 = f.render("Нажми пробел  чтобы начать" , 1, RED, None)
        window.blit(score_text2, (30, 250))

        f = pygame.font.Font("Korsinka//Shrift2.otf" , 35)
        score_text10 = f.render("Управление корзинкой клавишами A и D" , 1, WHITE, None)
        window.blit(score_text10, (30, 370))

        keys = pygame.key.get_pressed()

        if keys[pygame.K_SPACE]:
            start = 2 
            music_playing = False
            musik = 2
    elif start == 2:
        if musik == 2:
            musik2()
        f = pygame.font.Font("Korsinka//Shrift.ttf" , 35)
        score_text = f.render(f"Счёт:{score}" , 1, BLACK, None)

        f = pygame.font.Font("Korsinka//Shrift.ttf" , 35)
        score_text5 = f.render(f"Жизни:{lives}" , 1, BLACK, None)

        window.blit(bg_sprite2, (0, 0))
        window.blit(score_text, (400, 20))
        window.blit(score_text5, (200, 20))
        korsinka.draw()

        if wait == 0:
            wait = 5

            for i in range(aple):
                apple = Player("Korsinka//1234.png", randint(100, 500), randint(-2800, 50), 50, 50)
                apples.append(apple)

        else:

            for apple in apples:
                wait -= 1 
                apple.draw()   
                apple.fall_down()
                hit_apple = korsinka.rect.collidelist(apples)

                if hit_apple != -1 or apple.rect.y > 470: 
                    apples.remove(apple) 
                    wait = 0
                    speed += 0.05  

                if hit_apple != -1:  
                    score += 1
                    
                if apple.rect.y > 470:
                    lives -= 1

                if lives == 0:
                    start = 3  
                    music_playing = False
                    musik = 3
    elif start == 3:
        if musik == 3:
            musik3()
        keys = pygame.key.get_pressed()

        
        window.fill(BLACK)

        f = pygame.font.Font("Korsinka//bodoni-initials.ttf" , 35)
        score_text = f.render(f"Счёт:{score}" , 1, WHITE, None)
        score_text2 = f.render("Лучший счёт:" + str(stats["best"]), 1, WHITE, None)

        f = pygame.font.Font("Korsinka//bodoni-initials.ttf" , 45)
        score_text1 = f.render("Проигрыш" , 1, WHITE, None)
    
        f = pygame.font.Font("Korsinka//Shrift.ttf" , 25)
        score_text3 = f.render("Попробовать ещё раз?    Вернуться в меню?" , 1, WHITE, None)

        f = pygame.font.Font("Korsinka//Shrift.ttf" , 25)
        score_text4 = f.render("(клавиша r)           (клавиша q)" , 1, WHITE, None)

        if keys[pygame.K_q]:
            if score > stats["best"]:
                stats["best"] = score
                with open("Korsinka//best.json", "w", encoding="utf-8") as file:
                    json.dump(stats, file)
            start = 1
            score = 0
            lives = 3
            speed = 4
            musik = 1    
            apples.remove(apple)
            game = False

            
        window.blit(score_text3, (50, 300))
        window.blit(score_text4, (150, 350))
        window.blit(score_text1, (200, 100))
        window.blit(score_text2, (110, 150))
        window.blit(score_text, (320, 180))

        if keys[pygame.K_r]:
            if score > stats["best"]:
                stats["best"] = score
                with open("Korsinka//best.json", "w", encoding="utf-8") as file:
                    json.dump(stats, file)
            korsinka.rect.x = 300
            start = 2
            score = 0
            lives = 3
            speed = 4
            musik = 2    
            music_playing = False
    keys = pygame.key.get_pressed()

    if keys[pygame.K_d]:
        korsinka.rect.x += 10
    if keys[pygame.K_a]:
        korsinka.rect.x -= 10

    pygame.display.update()
    clock.tick(FPS)
    
    return not game
