from pygame import *
# 9makar(EA)
window = display.set_mode((500, 500))
display.set_caption("Maze")

class GameSprite(sprite.Sprite):
    def __init__(self, img, x, y, w, h, speed):
        super().__init__()
        
        self.image = transform.scale(
            image.load(img),
            (w, h)
        )
        
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
        self.speed = speed
        
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))

class Player(GameSprite):
    def update(self):
        keys = key.get_pressed()
        if keys[K_w]:
            self.rect.y -= self.speed
        if keys[K_d]:
            self.rect.x += self.speed
        if keys[K_s]:
            self.rect.y += self.speed
        if keys[K_a]:
            self.rect.x -= self.speed

class Enemy(GameSprite):
    def set_horizontal_path(self, start_x, end_x):
        self.start_x = start_x
        self.end_x = end_x
        self.direction_x = "RIGHT"
        
    def update(self):
        if self.rect.x >= self.end_x and self.direction_x == "RIGHT":
            self.end_x, self.start_x = self.start_x, self.end_x
            self.direction_x = "LEFT"
            
        if self.rect.x <= self.end_x and self.direction_x == "LEFT":
            self.end_x, self.start_x = self.start_x, self.end_x
            self.direction_x = "RIGHT"
            
        if self.direction_x == "RIGHT":
            self.rect.x += self.speed
        if self.direction_x == "LEFT":
            self.rect.x -= self.speed

class Wall(sprite.Sprite):
    def __init__(self, x, y, w, h, color):
        super().__init__()
        
        # ? Surface - поверхня
        self.image = Surface((w, h))
        # ? Залили поверхню коліром
        self.image.fill(color)
        # ? Отримали хітбокс
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = x, y
    
    def reset(self):
        # ? Малюємо зображення на координатах хітбокса
        window.blit(self.image, (self.rect.x, self.rect.y))

clock = time.Clock()

FPS = 60
game_run = True
game = True
game_over = 0

bg = GameSprite("labirint//background.jpg", 0, 0, 500, 500, 0)
player = Player("labirint//hero.png", 10, 300, 54, 54, 5)
finish = GameSprite("labirint//treasure.png", 30, 400, 64, 64, 0)

e1 = Enemy("labirint//cyborg2.webp", 500, 300, 64, 64, 3)
e1.set_horizontal_path(10, 500)

e2 = Enemy("labirint//cyborg2.webp", 10, 100, 64, 64, 3)
e2.set_horizontal_path(10, 500)

w1 = Wall(400, 280, 10, 100, (0, 150, 40))
w2 = Wall(200, 80, 10, 300, (0, 150, 40))
w3 = Wall(0, 370, 400, 10, (0, 150, 40))
w4 = Wall(100, 180, 10, 100, (0, 150, 40))
w5 = Wall(0, 180, 100, 10, (0, 150, 40))
w6 = Wall(100, 80, 300, 10, (0, 150, 40))
w7 = Wall(310, 180, 200, 10, (0, 150, 40))
w8 = Wall(310, 180, 10, 100, (0, 150, 40))
w9 = Wall(0, 495, 500, 10, (0, 150, 40))
w10 = Wall(0, -5, 500, 10, (0, 150, 40))
w11 = Wall(-5, 0, 10, 500, (0, 150, 40))
w12 = Wall(495, 0, 10, 500, (0, 150, 40))

enemys = sprite.Group()
enemys.add([e1, e2])

walls = sprite.Group()
walls.add([w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11, w12])

lose_sound = mixer.Sound("labirint//kick.mp3")
win_sound = mixer.Sound("labirint//money.mp3")

font.init()
win_text = font.SysFont("Arial", 62).render("You win!", True, (0, 100, 0))
lose_text = font.SysFont("Arial", 62).render("You lose!", True, (255, 20, 0))

def restart_labirint():
    global game, player, e1, e2, enemys
    
    game = True
    
    player = Player("labirint//hero.png", 10, 300, 54, 54, 5)

    e1 = Enemy("labirint//cyborg2.webp", 500, 300, 64, 64, 3)
    e1.set_horizontal_path(10, 500)

    e2 = Enemy("labirint//cyborg2.webp", 10, 100, 64, 64, 3)
    e2.set_horizontal_path(10, 500)
    
    enemys = sprite.Group()
    enemys.add([e1, e2])

def labirint_game():
    
    global game
    
    bg.reset()
    
    player.reset()
    player.update()
    
    enemys.draw(window)
    enemys.update()

    walls.draw(window)
    
    finish.reset()
    
    # ! sprite.spritecollide(SPRITE, GROUP, KILL_GROUP)
    # ! sprite.groupcollide(GROUP1, GROUP2, KILL_GROUP1, KILL_GROUP2)
    # ! sprite.collide_rect(SPRITE, SPRITE)
    
    if sprite.spritecollide(player, walls, False):
        lose_sound.play()
        window.blit(lose_text, (150, 300))
        game = False
        
    if sprite.spritecollide(player, enemys, False):
        lose_sound.play()
        window.blit(lose_text, (150, 300))
        game = False
        
    if sprite.collide_rect(player, finish):
        win_sound.play()
        window.blit(win_text, (150, 300))
        game = False
        
    clock.tick(FPS)
    display.update()
        
    return not game